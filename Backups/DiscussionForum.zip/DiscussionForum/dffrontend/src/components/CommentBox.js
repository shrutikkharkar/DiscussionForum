import React, {useState, useEffect, useContext} from 'react'
import axios from 'axios'
import Modal from 'react-bootstrap/Modal';

function CommentBox(props) {
    const [show, setShow] = useState(true);
    const [comments, setComment] = useState();

    const BEPORT = process.env.REACT_APP_BEPORT
    const BEHOST = process.env.REACT_APP_BEHOST
    const FEPORT = process.env.REACT_APP_FEPORT
    const FEHOST = process.env.REACT_APP_FEHOST

    useEffect(() => {
      getComments()
    }, []);
    
    function getComments() {
      try 
      { 
          //await axios.get(`${BEHOST}:${BEPORT}/comment/getComments/${props.answerId}`)
          axios.get(`${BEHOST}:${BEPORT}/comment/getComments/6155fc61a5ae5b2e20f8605e`)
          .then(response => {
              setComment(response.data);
              console.log(response.data);
          })
      } 
      catch (err) {
          console.error(err);
      }
  }

    return (
      <>
      
        <Modal
          show={show}
          size="lg"
          onHide={() => setShow(false)}
          dialogClassName="modal-90w"
          centered
          aria-labelledby="contained-modal-title-vcenter"
        >
          <Modal.Header closeButton>
            <Modal.Title id="example-custom-modal-styling-title">
              Answers over here
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
          
            <div>
              {comments.map(comment => (
                <p key={comment.id}>
                  {comment.comment}
                </p>
              ))}
            </div>

          </Modal.Body>
        </Modal>
      </>  
    )
}

export default CommentBox
